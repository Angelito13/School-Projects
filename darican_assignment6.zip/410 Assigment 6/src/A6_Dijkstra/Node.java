package A6_Dijkstra;
import java.util.HashMap;





public class Node {
String label;
long idNum;
int inDegree =0;
long distance = 50000;
boolean known;

//HashMap<String,Node> InMap = new HashMap<String,Node>();
//HashMap<String, Node> OutMap = new HashMap<String,Node>();
//HashMap<String, String> InMap = new HashMap<String,String>();
HashMap<String, Edge> inEdge = new HashMap <String, Edge>();
HashMap <String,Edge> outEdge = new HashMap<String, Edge>();



Node (long idNum, String label){
	this.label = label;
	this.idNum = idNum;
	this.known = false;
	
			
	
}
}
