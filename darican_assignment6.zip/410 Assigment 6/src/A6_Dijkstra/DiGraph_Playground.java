package A6_Dijkstra;

public class DiGraph_Playground {
	public static void main (String[] args) {
		
		exTest();
	}
	
	
	
	
	
	
	
	public static void exTest() {
		DiGraph d = new DiGraph();
		d.addNode(0, "0");
		d.addNode(1, "1");
		d.addNode(2, "2");
		d.addNode(3, "3");
		d.addNode(4, "4");
		d.addNode(5, "5");
		d.addNode(6, "6");
		d.addNode(7, "7");
		d.addEdge(0, "4", "5", 2, null);
		d.addEdge(1, "0", "5", 3, null);
		d.addEdge(2, "3", "2", 6, null);
		d.addEdge(3, "6", "1", 4, null);
		d.addEdge(4, "4", "0", 1, null);
		d.addEdge(5, "0", "7", 3, null);
//		d.addEdge(6, "d", "e", 3, null);
//		d.addEdge(7, "b", "e", 7, null);
//		d.addEdge(8, "a", "e", 9, null);
//		d.addEdge(9, "a", "d", 5, null);
//		d.addEdge(10, "g", "p", 2, null);
		printSHORT(d.shortestPath("0"));
	}
	
	public static void printSHORT(ShortestPathInfo[] shortestPathInfos){
	      System.out.print("Shortest Path: ");
	      for (ShortestPathInfo Nodes : shortestPathInfos) {
	      System.out.print(Nodes+" ");
	    }
	      System.out.println();
	    }

}
