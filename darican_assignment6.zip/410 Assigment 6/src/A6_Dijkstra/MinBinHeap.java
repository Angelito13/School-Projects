package A6_Dijkstra;



public class MinBinHeap implements Heap_Interface {
	  private ShortestPathInfo[] array; //load this array
	  private int size;
	  private static final int arraySize = 10000000; //Everything in the array will initially 
	                                              //be null. This is ok! Just build out 
	                                              //from array[1]

	  public MinBinHeap() {
	    this.array = new ShortestPathInfo[arraySize];
	    array[0] = new ShortestPathInfo(null, -100000); //0th will be unused for simplicity 
	    size = 0;                                         //of child/parent computations...
	                                             //the book/animation page both do this.
	  }
	    
	  //Please do not remove or modify this method! Used to test your entire Heap.
	  @Override
	  public ShortestPathInfo[] getHeap() { 
	    return this.array;
	  }

	@Override
	public void insert(ShortestPathInfo entry) {
		// TODO Auto-generated method stub
		if (size == 0) {
			array[1] = entry;
			size ++;
		}else {
			size ++;
			array[size] = entry;
			for ( int i = size; i >0; i--) {
				BubbleUp(i);
				
			}
			}
		}


	@Override
	public void delMin() {
	// TODO Auto-generated method stub
		ShortestPathInfo temp = array[size];
		array[size] = array[1];
		array[1] = temp;
		array[size] = null;
		size --;
		
		BubbleDown(1);
	}

	@Override
	public ShortestPathInfo getMin() {
		// TODO Auto-generated method stub
		return array[1];
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public void build(ShortestPathInfo[] entries) {
		// TODO Auto-generated method stub
		size = entries.length;
		for(int i = 0; i < size; i++) {
			array[i+1]=entries[i];
		}
		
		for (int i = size/2; i >0; i--) {
			BubbleDown(i);
		}
		
		/*for (int i = currentSize; i>0; i=i-2) {
			if (entries[i].getPriority() < entries[i-1].getPriority()) {
				if (entries[i].getPriority() <entries[i/2].getPriority()) {
					entries[i/2] = entries[i];
					entries[i]=entries[i/2];
				}
			}else {
				if (entries[i-1].getPriority() < entries[i/2].getPriority()) {
					entries[i/2] = entries[i-1];
					entries[i-1] = entries[i/2];
				}
			}
		}*/
		
	}
	public void BubbleDown(int index) {
		if (array[index*2] != null && array[index*2+1]==null) {
			if(array[index*2].getTotalWeight() < array[index].getTotalWeight()) {
				ShortestPathInfo temp = array[index*2];
				array[index*2] = array[index];
				array[index] = temp;
			}
			
		}else if(array[index*2] != null && array[index*2+1]!=null) {
			if (array[index*2].getTotalWeight() < array[index*2+1].getTotalWeight()) {
				if (array[index*2].getTotalWeight() < array[index].getTotalWeight()) {
					ShortestPathInfo temp = array[index*2];
					array[index*2] = array[index];
					array[index] = temp;
					if(index * 4 <= size)BubbleDown(index*2);
				}
			}else {
				if (array[index*2+1].getTotalWeight() < array[index].getTotalWeight()) {
					ShortestPathInfo temp = array[index*2+1] ;
					array[index*2+1] = array[index];
					array[index] = temp;
					if(2*((index *2) + 1) <= size) BubbleDown(index*2+1);
				}
			}
		}else if (array[index*2] == null && array[index*2+1]==null) {
			return;
		}
	}

	public void BubbleUp(int index) {
		if (array[index/2] != null) {
			if (array[index].getTotalWeight() < array[index/2].getTotalWeight()) {
				ShortestPathInfo temp = array[index];
				array[index] = array[index/2];
				array[index/2]=temp;
				BubbleUp(index);
			}
		}else if (array[index/2]==null) {
			return;
		}
	}
	}

