package A6_Dijkstra;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Queue;
import java.util.LinkedList;
import java.util.PriorityQueue;

public class DiGraph implements DiGraph_Interface {
int countNode = 0;
int countEdge = 0;


// in here go all your data and methods for the graph
  // and the topo sort operation
 HashSet<Long> NodeidSet = new HashSet<Long>();
 HashMap<String, Node> NodesMap= new HashMap<String,Node>();
 HashSet<String> NodesSet = new HashSet<String>();
 ArrayList<Node> NodeList = new ArrayList<Node>();
 HashSet<Long> EdgeidSet = new HashSet<Long>();



  public DiGraph ( ) { 
	// default constructor
    // explicitly include this
    // we need to have the default constructor
    // if you then write others, this one will still be there  
  }

@Override
public boolean addNode(long idNum, String label) {
	// TODO Auto-generated method stub
	 	Node newNode = new Node(idNum,label);
	 	
	 	//NodesMap.containsValue(newNode) == true ||
	 	
	if(NodesSet.contains(label)== true ||  idNum <0 || label == null || NodeidSet.contains(idNum)==true) {
		return false;
	}else {
		NodesMap.put(label, newNode);
		NodesSet.add(label);
		NodeList.add(newNode);
		NodeidSet.add(idNum);
		
		countNode++;
		return true;
	}
}

@Override
public boolean addEdge(long idNum, String sLabel, String dLabel, long weight, String eLabel) {
	// TODO Auto-generated method stub
		Node start = NodesMap.get(sLabel);
		Node destination = NodesMap.get(dLabel);
		//Not sure if on right track
		Edge newEdge = new Edge(idNum, sLabel, dLabel, weight, eLabel);
		
		//fix checks
	if (idNum <0 || EdgeidSet.contains(idNum) == true || NodesMap.containsKey(sLabel)==false 	|| NodesMap.containsKey(dLabel)==false ||
			start.outEdge.containsKey(dLabel) == true || 
			destination.inEdge.containsKey(sLabel) == true)
		 {
		return false;
	} else {
		start.outEdge.put(dLabel, newEdge);
		destination.inEdge.put(sLabel, newEdge);
		
		EdgeidSet.add(idNum);
		
		NodesMap.get(dLabel).inDegree++;
		
		countEdge++;
		return true;
	}
	
}

@Override
public boolean delNode(String label) {
	// TODO Auto-generated method stub
	if(NodesSet.contains(label) == false) {
		return false;
	} else {
		for (String sourcelabel : NodesMap.get(label).inEdge.keySet()) {
			NodesMap.get(sourcelabel).outEdge.remove(label);
		}
		for (String sourcelabel : NodesMap.get(label).outEdge.keySet()) {
			NodesMap.get(sourcelabel).inEdge.remove(label);
			NodesMap.get(sourcelabel).inDegree--;
			
		}
//		NodesMap.get(label).inEdge.remove(label);
//		NodesMap.get(label).outEdge.remove(label);
		NodeList.remove(NodesMap.get(label));
		NodeidSet.remove(NodesMap.get(label).idNum);
		NodesMap.remove(label);
		NodesSet.remove(label);
		
		
		
		countNode--;
		return true;
		
	}
	
}

@Override
public boolean delEdge(String sLabel, String dLabel) {
	// TODO Auto-generated method stub
	Node start = NodesMap.get(sLabel);
	Node destination = NodesMap.get(dLabel);
	
	if(NodesMap.containsKey(sLabel) == false|| NodesMap.containsKey(dLabel) == false || start.outEdge.containsKey(dLabel) == false || destination.inEdge.containsKey(sLabel) == false) {
		return false;
	}else {
		
		EdgeidSet.remove(start.outEdge.get(dLabel).idNum);
		
		start.outEdge.remove(dLabel);
		destination.inEdge.remove(sLabel);
		
		NodesMap.get(dLabel).inDegree--;
		
		countEdge--;
		return true;
	}

}

@Override
public long numNodes() {
	// TODO Auto-generated method stub
	return countNode;
}

@Override
public long numEdges() {
	// TODO Auto-generated method stub
	return countEdge;
}

@Override
public String[] topoSort() {
	// TODO Auto-generated method stub
	
	String[] TopoList = new String[NodeList.size()];
	//ArrayList<Node> TopoArray= new ArrayList<Node>();
	Queue<Node> WorkingSet = new LinkedList<Node>();
	
while (NodesMap.isEmpty() == false) {
	//Node tempNode = null;
	for (Node dNode : NodeList ) {
		if (dNode.inDegree == 0) {
			WorkingSet.add(dNode);
			//tempNode = dNode;
			//TopoQ.add(dNode);
			//NodeList.remove(dNode);
			//System.out.print(tempNode.label);
//			TopoQ.add(dNode);
			//this.delNode(dNode.label);
		}
	}
	
	if (WorkingSet.isEmpty() == true && TopoList.length != NodeList.size()) {
		return null;
	}else {
		for(int i =0; i<TopoList.length; i++) {
			
			Node PopOff = WorkingSet.poll();
			if(PopOff== null)return null;
			TopoList[i] = PopOff.label;
			for (String s : PopOff.outEdge.keySet()) {
				Node n = NodesMap.get(s);
				if(n.inDegree==1) {
					WorkingSet.add(n);
				}
			}
			this.delNode(PopOff.label);
			
			
		}
		
	}
}
		return TopoList;
	}

@Override
public ShortestPathInfo[] shortestPath(String label) {
	//MinBinHeap KnownNodes = new MinBinHeap();
	MinBinHeap Adjacent_Nodes = new MinBinHeap();
	ShortestPathInfo[] ShortestList = new ShortestPathInfo[NodeList.size()];
	

	ShortestPathInfo StartNode = new ShortestPathInfo(label, 0);
	Adjacent_Nodes.insert(StartNode);
	
	
		while (Adjacent_Nodes.size() != 0) {
			ShortestPathInfo Min = Adjacent_Nodes.getMin();
			Node minNode = NodesMap.get(Min.getDest());


			if (minNode.known == true) {
				Adjacent_Nodes.delMin();
			} else {
				minNode.known = true;
				minNode.distance = Min.getTotalWeight();
				Adjacent_Nodes.delMin();
				

				
					for (String s : minNode.outEdge.keySet()) {
						Node adjacent = NodesMap.get(s);
						if (adjacent.known == false) {
							if(adjacent.distance > Min.getTotalWeight() + minNode.outEdge.get(s).weight) {
							adjacent.distance = Min.getTotalWeight() + minNode.outEdge.get(s).weight;
							ShortestPathInfo adjacent_node = new ShortestPathInfo(s, adjacent.distance);
							Adjacent_Nodes.insert(adjacent_node);
							}

						}
					}

			}
		
		}
	

		int count = 0;
			for(Node n : NodeList) {
				if(n.distance == 50000) {
					n.distance = -1;
					
				}
			ShortestList[count] = new ShortestPathInfo(n.label, n.distance);
			count ++;
			}
		

		return ShortestList;

	}
}

