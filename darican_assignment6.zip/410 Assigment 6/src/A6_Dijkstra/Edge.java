package A6_Dijkstra;

public class Edge {
long weight;
String start;
String destination;
String label;
long idNum;

//public static HashMap<String, String> inEdge = new HashMap<String,String>();
//public static HashMap<String, String> outEdge= new HashMap<String,String>();




	Edge(long idNum, String start, String destination, long weight, String label){
		this.weight = weight;
		this.start = start;
		this.destination = destination;
		this.label = label;
		//inEdge.put(label, destination);
		//outEdge.put(label, start);
		//EdgeSet.add(idNum);
	}
}
